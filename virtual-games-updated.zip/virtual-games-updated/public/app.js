const api = (path, opts={})=>{
  const base = '/api';
  return fetch(base+path, opts).then(r=>r.json());
};

function setToken(t){
  if(t) localStorage.setItem('token', t);
  else localStorage.removeItem('token');
}
function getToken(){ return localStorage.getItem('token'); }

async function signup(){
  const email=document.getElementById('email').value;
  const password=document.getElementById('password').value;
  const name=document.getElementById('name').value;
  const res = await api('/signup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,name})});
  if(res.token){ setToken(res.token); showLoggedIn(); alert('Signed up'); }
  else alert(JSON.stringify(res));
}

async function login(){
  const email=document.getElementById('email').value;
  const password=document.getElementById('password').value;
  const res = await api('/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
  if(res.token){ setToken(res.token); showLoggedIn(); alert('Logged in'); }
  else alert(JSON.stringify(res));
}

function authOpts(opts={}){
  const headers = opts.headers||{};
  const t = getToken();
  if(t) headers['Authorization']='Bearer '+t;
  opts.headers = headers;
  return opts;
}

async function showLoggedIn(){
  document.getElementById('auth').style.display='none';
  document.getElementById('profile').style.display='block';
  document.getElementById('wallet').style.display='block';
  refreshProfile();
  loadGames();
}

async function refreshProfile(){
  const res = await fetch('/api/profile', authOpts()).then(r=>r.json());
  document.getElementById('me').innerText = JSON.stringify(res);
  const w = await fetch('/api/wallet', authOpts()).then(r=>r.json());
  document.getElementById('credits').innerText = w.credits;
}

async function deposit(){
  const amount = Number(document.getElementById('depositAmount').value||0);
  const res = await fetch('/api/wallet/deposit', authOpts({method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({amount})})).then(r=>r.json());
  alert(JSON.stringify(res));
  refreshProfile();
}

async function requestWithdraw(){
  const amount = Number(document.getElementById('withdrawAmount').value||0);
  const upi = document.getElementById('upi').value || '';
  const utr = document.getElementById('utr').value || '';
  const res = await fetch('/api/wallet/withdraw', authOpts({method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({amount,upi,utr})})).then(r=>r.json());
  alert(JSON.stringify(res));
  refreshProfile();
}

async function loadGames(){
  const g = await fetch('/api/games').then(r=>r.json());
  const el = document.getElementById('gamesList');
  el.innerHTML = '';
  g.forEach(game=>{
    const d = document.createElement('div');
    d.innerHTML = `<strong>${game.title}</strong> — <em>${game.description}</em>`;
    el.appendChild(d);
  });
}

// auto show if token exists
if(getToken()) showLoggedIn();
